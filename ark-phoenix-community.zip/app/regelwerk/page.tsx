"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Shield, AlertTriangle, Users, Zap, Ban, Clock, CheckCircle, XCircle, Menu } from "lucide-react"

export default function RulesPage() {
  return (
    <div className="min-h-screen bg-background">
      <nav className="bg-card border-b-2 border-primary/20 shadow-lg">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            {/* Logo/Brand */}
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center">
                <Zap className="h-5 w-5 text-primary-foreground" />
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                Infinity of Phoenix
              </span>
            </div>

            {/* Navigation Menu */}
            <div className="hidden md:flex items-center space-x-8">
              <Button variant="ghost" className="text-primary font-medium border-b-2 border-primary">
                Rules
              </Button>
              <Button variant="ghost" className="text-foreground font-medium">
                Server Informations
              </Button>
              <Button variant="ghost" className="text-foreground font-medium">
                Inspector
              </Button>
              <Button variant="ghost" className="text-foreground font-medium">
                Map Info
              </Button>
            </div>

            {/* Mobile Menu Button */}
            <div className="md:hidden">
              <Button variant="ghost" size="sm">
                <Menu className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="relative bg-gradient-to-br from-primary/20 via-background to-accent/10 border-b border-border">
        <div className="absolute inset-0 bg-[url('/phoenix-rising-from-flames-mythical-fire-bird.png')] bg-cover bg-center opacity-10" />
        <div className="relative container mx-auto px-4 py-16 text-center">
          <div className="mb-6">
            <h1 className="text-6xl font-bold text-balance mb-4 bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              Server Rules
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto text-pretty">
              Befolge diese Regeln für ein faires und spaßiges Spielerlebnis auf unserem Infinity of Phoenix Server.
            </p>
          </div>
          <div className="flex flex-wrap gap-4 justify-center">
            <Button size="lg" className="border border-primary">
              <Shield className="mr-2 h-5 w-5" />
              Report Player
            </Button>
            <Button size="lg" variant="secondary" className="border border-secondary">
              <Users className="mr-2 h-5 w-5" />
              Contact Admin
            </Button>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Rule Categories Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-card border-border">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">General Rules</CardTitle>
              <Shield className="h-4 w-4 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary">8</div>
              <p className="text-xs text-muted-foreground">Basic conduct rules</p>
            </CardContent>
          </Card>

          <Card className="bg-card border-border">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">PvP Rules</CardTitle>
              <AlertTriangle className="h-4 w-4 text-secondary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-secondary">6</div>
              <p className="text-xs text-muted-foreground">Combat regulations</p>
            </CardContent>
          </Card>

          <Card className="bg-card border-border">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Building Rules</CardTitle>
              <Zap className="h-4 w-4 text-accent" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-accent">5</div>
              <p className="text-xs text-muted-foreground">Construction guidelines</p>
            </CardContent>
          </Card>

          <Card className="bg-card border-border">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Penalties</CardTitle>
              <Ban className="h-4 w-4 text-destructive" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-destructive">3</div>
              <p className="text-xs text-muted-foreground">Violation consequences</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Rules Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* General Rules */}
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="h-5 w-5 text-primary" />
                  Allgemeine Regeln
                </CardTitle>
                <CardDescription>Grundlegende Verhaltensregeln für alle Spieler</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="text-sm font-medium">Respektvoller Umgang</p>
                      <p className="text-xs text-muted-foreground">Behandle alle Spieler mit Respekt und Höflichkeit</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <XCircle className="h-5 w-5 text-red-500 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="text-sm font-medium">Kein Spam oder Belästigung</p>
                      <p className="text-xs text-muted-foreground">
                        Spam, Belästigung oder toxisches Verhalten ist verboten
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <XCircle className="h-5 w-5 text-red-500 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="text-sm font-medium">Keine Cheats oder Exploits</p>
                      <p className="text-xs text-muted-foreground">
                        Verwendung von Cheats, Hacks oder Exploits führt zum sofortigen Ban
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="text-sm font-medium">Deutsche Sprache bevorzugt</p>
                      <p className="text-xs text-muted-foreground">Kommunikation im globalen Chat bitte auf Deutsch</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* PvP Rules */}
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-secondary" />
                  PvP Regeln
                </CardTitle>
                <CardDescription>PvP ist nur an Wochenenden erlaubt (Freitag 18:00 - Sonntag 23:59)</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-3 bg-secondary/10 rounded-lg border border-secondary/20">
                  <div className="flex items-center gap-2 mb-2">
                    <Clock className="h-4 w-4 text-secondary" />
                    <span className="text-sm font-medium">PvP Zeiten</span>
                  </div>
                  <p className="text-xs text-muted-foreground">Freitag 18:00 - Sonntag 23:59 Uhr</p>
                </div>
                <div className="space-y-3">
                  <div className="flex items-start gap-3">
                    <XCircle className="h-5 w-5 text-red-500 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="text-sm font-medium">Kein Offline-Raiding</p>
                      <p className="text-xs text-muted-foreground">Angriffe auf offline Spieler sind verboten</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <XCircle className="h-5 w-5 text-red-500 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="text-sm font-medium">Kein Foundation Wiping</p>
                      <p className="text-xs text-muted-foreground">Komplette Zerstörung von Basen ist nicht erlaubt</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="text-sm font-medium">Faire Kämpfe</p>
                      <p className="text-xs text-muted-foreground">Übermäßiges Camping oder Griefing ist verboten</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Building Rules */}
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-accent" />
                  Bau Regeln
                </CardTitle>
                <CardDescription>Richtlinien für das Bauen und Platzieren von Strukturen</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex items-start gap-3">
                    <XCircle className="h-5 w-5 text-red-500 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="text-sm font-medium">Kein Blockieren von Ressourcen</p>
                      <p className="text-xs text-muted-foreground">
                        Wichtige Ressourcen-Spawns dürfen nicht blockiert werden
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <XCircle className="h-5 w-5 text-red-500 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="text-sm font-medium">Keine Pillar-Spam</p>
                      <p className="text-xs text-muted-foreground">
                        Übermäßiges Platzieren von Säulen zum Landclaiming ist verboten
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="text-sm font-medium">Angemessene Baugröße</p>
                      <p className="text-xs text-muted-foreground">Basen sollten der Tribegröße angemessen sein</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Penalty System */}
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Ban className="h-5 w-5 text-destructive" />
                  Strafen System
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-3">
                  <div className="p-3 bg-yellow-500/10 rounded-lg border border-yellow-500/20">
                    <div className="flex items-center gap-2 mb-1">
                      <AlertTriangle className="h-4 w-4 text-yellow-500" />
                      <span className="text-sm font-medium">Verwarnung</span>
                    </div>
                    <p className="text-xs text-muted-foreground">Erste Regelverletzung</p>
                  </div>
                  <div className="p-3 bg-orange-500/10 rounded-lg border border-orange-500/20">
                    <div className="flex items-center gap-2 mb-1">
                      <Clock className="h-4 w-4 text-orange-500" />
                      <span className="text-sm font-medium">Temporärer Ban</span>
                    </div>
                    <p className="text-xs text-muted-foreground">1-7 Tage je nach Schwere</p>
                  </div>
                  <div className="p-3 bg-red-500/10 rounded-lg border border-red-500/20">
                    <div className="flex items-center gap-2 mb-1">
                      <Ban className="h-4 w-4 text-red-500" />
                      <span className="text-sm font-medium">Permanenter Ban</span>
                    </div>
                    <p className="text-xs text-muted-foreground">Schwere oder wiederholte Verstöße</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Admin Contact */}
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-lg">Admin Kontakt</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button variant="outline" className="w-full justify-start border border-border bg-transparent">
                  <Users className="mr-2 h-4 w-4" />
                  Discord Support
                </Button>
                <Button variant="outline" className="w-full justify-start border border-border bg-transparent">
                  <Shield className="mr-2 h-4 w-4" />
                  Report Player
                </Button>
                <Button variant="outline" className="w-full justify-start border border-border bg-transparent">
                  <AlertTriangle className="mr-2 h-4 w-4" />
                  Appeal Ban
                </Button>
              </CardContent>
            </Card>

            {/* Quick Rules Summary */}
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-lg">Wichtigste Regeln</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="text-xs space-y-1">
                  <p>• Respektvoller Umgang</p>
                  <p>• PvP nur am Wochenende</p>
                  <p>• Keine Cheats/Exploits</p>
                  <p>• Kein Offline-Raiding</p>
                  <p>• Keine Ressourcen blockieren</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
