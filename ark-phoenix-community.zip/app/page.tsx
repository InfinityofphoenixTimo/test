"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { Progress } from "@/components/ui/progress"
import { Activity, Server, Users, Zap, Shield, Clock, MapPin, Settings, Menu } from "lucide-react"

export default function ArkPhoenixCommunity() {
  return (
    <div className="min-h-screen bg-background">
      <nav className="bg-card border-b-2 border-primary/20 shadow-lg">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            {/* Logo/Brand */}
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center">
                <Zap className="h-5 w-5 text-primary-foreground" />
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                Infinity of Phoenix
              </span>
            </div>

            {/* Navigation Menu */}
            <div className="hidden md:flex items-center space-x-8">
              <Button variant="ghost" className="text-foreground font-medium" asChild>
                <a href="/regelwerk">Regelwerk</a>
              </Button>
              <Button variant="ghost" className="text-foreground font-medium" asChild>
                <a href="/server-informations">Server Informations</a>
              </Button>
              <Button variant="ghost" className="text-foreground font-medium" asChild>
                <a href="/inspector">Inspector</a>
              </Button>
              <Button variant="ghost" className="text-foreground font-medium" asChild>
                <a href="/map-info">Map Info</a>
              </Button>
            </div>

            {/* Mobile Menu Button */}
            <div className="md:hidden">
              <Button variant="ghost" size="sm">
                <Menu className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="relative bg-gradient-to-br from-primary/20 via-background to-accent/10 border-b border-border">
        <div className="absolute inset-0 bg-[url('/phoenix-rising-from-flames-mythical-fire-bird.png')] bg-cover bg-center opacity-10" />
        <div className="relative container mx-auto px-4 py-16 text-center">
          <div className="mb-6">
            <h1 className="text-6xl font-bold text-balance mb-4 bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              Infinity of Phoenix
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto text-pretty">
              {
                "Erlebe dein bestes ARK Survival Ascended Abenteuer mit exklusiven Features, einer aktiver Community und professionellem Team."
              }
            </p>
          </div>
          <div className="flex flex-wrap gap-4 justify-center">
            <Button size="lg" className="border border-primary">
              <Server className="mr-2 h-5 w-5" />
              Join Server
            </Button>
            <Button size="lg" variant="secondary" className="border border-secondary">
              <Users className="mr-2 h-5 w-5" />
              Community Discord
            </Button>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Server Status Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-card border-border">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Server Status</CardTitle>
              <Activity className="h-4 w-4 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary">ONLINE</div>
              <p className="text-xs text-muted-foreground">99.9% uptime</p>
            </CardContent>
          </Card>

          <Card className="bg-card border-border">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Players Online</CardTitle>
              <Users className="h-4 w-4 text-secondary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-secondary">47/70</div>
              <p className="text-xs text-muted-foreground">Peak: 68 today</p>
            </CardContent>
          </Card>

          <Card className="bg-card border-border">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Server Performance</CardTitle>
              <Zap className="h-4 w-4 text-accent" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-accent">Excellent</div>
              <p className="text-xs text-muted-foreground">15ms avg latency</p>
            </CardContent>
          </Card>

          <Card className="bg-card border-border">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Next Restart</CardTitle>
              <Clock className="h-4 w-4 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">6h 23m</div>
              <p className="text-xs text-muted-foreground">Daily at 6:00 AM</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Server Information */}
          <div className="lg:col-span-2 space-y-6">
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Server className="h-5 w-5 text-primary" />
                  Server Information
                </CardTitle>
                <CardDescription>
                  Infinity of Phoenix - PvPvE Cluster with enhanced rates and custom content
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Map</span>
                      <Badge variant="secondary">The Island</Badge>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Max Players</span>
                      <span className="text-sm font-medium">70</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Taming Rate</span>
                      <span className="text-sm font-medium text-secondary">5x</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Harvest Rate</span>
                      <span className="text-sm font-medium text-secondary">3x</span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">XP Rate</span>
                      <span className="text-sm font-medium text-secondary">2x</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Breeding Rate</span>
                      <span className="text-sm font-medium text-secondary">10x</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">PvP</span>
                      <Badge variant="destructive">Weekends Only</Badge>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Wipe Schedule</span>
                      <span className="text-sm font-medium">Never</span>
                    </div>
                  </div>
                </div>

                <Separator />

                <div>
                  <h4 className="text-sm font-medium mb-2">Server Resources</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">CPU Usage</span>
                      <span className="text-sm">45%</span>
                    </div>
                    <Progress value={45} className="h-2" />

                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">Memory Usage</span>
                      <span className="text-sm">62%</span>
                    </div>
                    <Progress value={62} className="h-2" />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Community Features */}
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5 text-secondary" />
                  Community Features
                </CardTitle>
                <CardDescription>Enhanced gameplay with custom mods and community events</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-3">
                    <div className="flex items-center gap-2">
                      <Shield className="h-4 w-4 text-primary" />
                      <span className="text-sm">Anti-Grief Protection</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <MapPin className="h-4 w-4 text-accent" />
                      <span className="text-sm">Custom Spawn Points</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Zap className="h-4 w-4 text-secondary" />
                      <span className="text-sm">Quality of Life Mods</span>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <div className="flex items-center gap-2">
                      <Settings className="h-4 w-4 text-primary" />
                      <span className="text-sm">Admin Support 24/7</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Activity className="h-4 w-4 text-accent" />
                      <span className="text-sm">Weekly Events</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Users className="h-4 w-4 text-secondary" />
                      <span className="text-sm">Tribe Alliances</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Quick Connect */}
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-lg">Quick Connect</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="p-3 bg-muted rounded-lg">
                  <p className="text-xs text-muted-foreground mb-1">Server IP</p>
                  <p className="font-mono text-sm">phoenix.arkserver.net:7777</p>
                </div>
                <Button className="w-full border border-border bg-transparent" variant="outline">
                  Copy Server IP
                </Button>
                <Button className="w-full border border-primary">Launch ARK</Button>
              </CardContent>
            </Card>

            {/* Recent Updates */}
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-lg">Recent Updates</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-sm font-medium">Phoenix Event Active</p>
                      <p className="text-xs text-muted-foreground">Double XP weekend</p>
                    </div>
                    <Badge className="bg-secondary text-secondary-foreground">New</Badge>
                  </div>
                  <Separator />
                  <div>
                    <p className="text-sm font-medium">Server Optimization</p>
                    <p className="text-xs text-muted-foreground">Improved performance</p>
                  </div>
                  <Separator />
                  <div>
                    <p className="text-sm font-medium">New Mod Added</p>
                    <p className="text-xs text-muted-foreground">Structures Plus updated</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Community Links */}
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-lg">Community</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button variant="outline" className="w-full justify-start border border-border bg-transparent" asChild>
                  <a href="https://discord.gg/infinityofphoenix">
                    <Users className="mr-2 h-4 w-4" />
                    Discord Server
                  </a>
                </Button>
                <Button variant="outline" className="w-full justify-start border border-border bg-transparent" asChild>
                  <a href="/forums.infinityofphoenix.com">
                    <Activity className="mr-2 h-4 w-4" />
                    Forums
                  </a>
                </Button>
                <Button variant="outline" className="w-full justify-start border border-border bg-transparent" asChild>
                  <a href="/regelwerk">
                    <Shield className="mr-2 h-4 w-4" />
                    Rules & Guidelines
                  </a>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
